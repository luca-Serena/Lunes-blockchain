#!/usr/bin/env python3
import os
import numpy as np
import re
import matplotlib.pyplot as plt

threshold = 10000 // 2  # 50% of nodes should have received the attacker's block
hashrate = re.compile(r"test-51-(\d+)-parsed.txt")
maxid = re.compile(r"MAXID:\s(\d{1,4})")
rcvn = re.compile(r"recv: (\d+)")

results = {}

# CHANGE THE FOLDER TO READ THE CORRECT FILES
for filename in os.listdir(os.getcwd()):
    if "parsed.txt" in filename:
        h = int(re.findall(hashrate, filename)[0])
        count = 0
        for i, line in enumerate(open(filename)):
            for match in re.finditer(maxid, line):
                thismax = int(match.group(1))
            for match in re.finditer(rcvn, line):
                r = int(match.group(1))
                if r > threshold:
                    count += 1
        # k: hashrate, v: %success
        results[h] = (count / thismax) * 100

assert (len(results) == 100)

lists = sorted(results.items())
x, y = zip(*lists)
fig, ax = plt.subplots()
plt.plot(x, y, label="% of success")
plt.xticks([i for i in range(0, 100, 10)])
plt.yticks([i for i in range(0, 100, 10)])
plt.title("51% Attack")
plt.xlabel("Attacker's hashrate")
plt.ylabel("% of success")
# Find the % of success with 51% hashrate
y = ax.lines[0].get_ydata()[np.where(ax.lines[0].get_xdata() == 51)[0][0]]
plt.scatter(51, y, c="red")
s = "Hashrate 51%, success: {}%".format(round(y, 2))
ax.annotate(s, xy=(51 + 1, y - 1))
ax.grid(True)
ax.legend(loc=2)
for i, v in enumerate(ax.lines[0].get_ydata()):
    if int(v) == 50:
        x = ax.lines[0].get_xdata()[i]
        s = "Hashrate {}%, success: 50%".format(x)
        plt.scatter(x - 0.4, v - 0.6, c="red")
        ax.annotate(s, xy=(x - 22, v))
plt.show()
